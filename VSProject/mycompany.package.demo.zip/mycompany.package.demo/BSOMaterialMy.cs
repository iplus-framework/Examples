﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mycompany.bso.erp;
using gip.core.datamodel;
using gip.core.autocomponent;
using mycompany.package.datamodel;

namespace mycompany.package.demo
{
    [ACClassInfo("mycompany.erp", "en{'Material my BSO'}de{'Material mein BSO'}", Global.ACKinds.TACBSO, Global.ACStorableTypes.NotStorable, true, true, Const.QueryPrefix + Material.ClassName)]
    public class BSOMaterialMy : BSOMaterial
    {
        public BSOMaterialMy(ACClass acType, IACObject content, IACObject parentACObject, ACValueList parameter, string acIdentifier = "")
            : base(acType, content, parentACObject, parameter, acIdentifier)
        {
        }

        [ACMethodCommand("", "en{'My Method'}de{'Meine Methode'}", 100, true)]
        public void MyMethod()
        {
            IACComponent proxyComp = ACUrlCommand(@"\AppExample\Comp1") as IACComponent;
            if (proxyComp != null && CurrentMaterial != null)
            {
                IACContainerT<int> myCounter = proxyComp.GetPropertyNet("MyCounter") as IACContainerT<int>;
                if (myCounter != null)
                    CurrentMaterial.MaterialName1 = String.Format("Current value: {0}", myCounter.ValueT);
            }
        }
    }
}
