﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gip.core.datamodel;
using gip.core.autocomponent;
using mycompany.package.datamodel;

namespace mycompany.package.demo
{
    [ACClassInfo("mycompany.erp", "en{'My example component'}de{'Meine Beispielkomponente'}", Global.ACKinds.TPAModule, Global.ACStorableTypes.Required)]
    public class MyDemoComp : PAClassAlarmingBase
    {
        public MyDemoComp(ACClass acType, IACObject content, IACObject parentACObject, ACValueList parameter, string acIdentifier = "")
              : base(acType, content, parentACObject, parameter, acIdentifier)
        {
        }

        [ACPropertyBindingTarget(100, "", "en{'My Counter'}de{'Mein Zähler'}")]
        public IACContainerTNet<int> MyCounter { get; set; }

        [ACPropertyBindingSource(100, "", "en{'Odd'}de{'Ungerade'}")]
        public IACContainerTNet<bool> MyIsOdd { get; set; }

        [ACMethodInteraction("", "en{'Increase'}de{'Erhöhe'}", 100, true)]
        public void MyMethod()
        {
            MyCounter.ValueT++;
            MyIsOdd.ValueT = MyCounter.ValueT % 2 != 0;
            using (var db = new MyCompanyDB())
            {
                var mat = db.Material.Where(c => c.MaterialNo.Contains(MyCounter.ValueT.ToString())).FirstOrDefault();
                if (mat != null)
                    mat.MaterialName1 = "Found";
            }
        }
    }
}
